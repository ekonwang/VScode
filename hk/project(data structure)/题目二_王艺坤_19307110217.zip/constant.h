#ifndef _CONSTANT_H_
#define _CONSTANT_H_

#define LargeYear 99999
#define LargeMonth 12
#define LargeDate 31
#define LargeHour 23
#define Largemin  59
#define LargePrice 1499999

#define MaxStation 16
#define MaxCityNum 25
#define MaxPrice 50000

#endif //_CONSTANT_H_
#pragma once
